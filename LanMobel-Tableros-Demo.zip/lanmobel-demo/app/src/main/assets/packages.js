/* One physical package has one QR and a counted number of boards. Dimensions: mm. */
(function(root){
'use strict';
const key='lanmobel-packages-demo-v1',legacyKey='lanmobel-stock-demo-v1';
const colors=['Jazmín','Nómada','Cielo','Humo','Kenya','Haya','Juice','Mustard','Trufa','Nude'];
const thicknesses=[19,35,10,4];
const clone=value=>JSON.parse(JSON.stringify(value));
function integer(value,label,min=1,max=20000){if(String(value).trim()==='')throw Error('Indica '+label+'.');const n=Number(value);if(!Number.isInteger(n)||n<min||n>max)throw Error(label+': usa un número entero entre '+min+' y '+max+'.');return n;}
function text(value,label,max=60){if(typeof value!=='string'||!value.trim()||value.trim().length>max)throw Error('Revisa '+label+'.');return value.trim();}
function fresh(){return {model:'packages',version:1,workspace:Math.random().toString(36).slice(2,10).padEnd(8,'0'),next:1,packages:[],events:[]};}
function unit(db,id){const p=db.packages.find(p=>p.id===id);if(!p)throw Error('Paquete no encontrado.');return p;}
function event(db,type,p,message){db.events.unshift({type,packageId:p.id,date:new Date().toISOString(),message});}
function transaction(db,change){const next=clone(db);change(next);return next;}
function receive(db,input){return transaction(db,next=>{
 const color=text(input.color,'el color'),length=integer(input.length,'Largo'),width=integer(input.width,'Ancho'),thickness=integer(input.thickness,'Grosor',1,100),quantity=integer(input.quantity,'Tableros contados',1,1000);
 const id='PK-'+String(next.next++).padStart(5,'0'),date=new Date().toISOString();
 const reference=String(input.lot||'').trim()||'REC-'+date.slice(0,10).replace(/-/g,'')+'-'+id.slice(3);
 const p={id,color,length,width,thickness,quantity,lot:text(reference,'el albarán',40),location:null,status:'muelle',labelConfirmed:false,receivedAt:date,sample:!!input.sample};
 next.packages.push(p);event(next,'recepcion',p,'Paquete recibido · '+quantity+' tableros · '+color);
 });}
function confirmLabel(db,id){return transaction(db,next=>{const p=unit(next,id);if(p.labelConfirmed)return;p.labelConfirmed=true;event(next,'etiqueta',p,'Etiqueta QR colocada en el tablero superior');});}
function store(db,id,location){return transaction(db,next=>{
 const p=unit(next,id);if(!p.labelConfirmed)throw Error('Confirma primero que has colocado la etiqueta QR en el paquete.');
 const destination=text(location,'la ubicación',30).toLocaleUpperCase('es');if(destination==='MUELLE')throw Error('Elige una ubicación de almacén, por ejemplo A-01.');
 if(p.status==='almacen'&&p.location===destination)return;
 const previous=p.location;p.location=destination;p.status='almacen';
 event(next,'ubicacion',p,previous?'Paquete trasladado · '+previous+' → '+destination:'Paquete almacenado · '+destination+' · '+p.quantity+' tableros');
 });}
function payload(db,p){return 'LMBPKG:'+db.workspace+':'+p.id;}
function lookup(db,value){const raw=String(value).trim();let id=raw;if(raw.startsWith('LMBPKG:')){const parts=raw.split(':');if(parts.length!==3||parts[1]!==db.workspace)throw Error('Este QR pertenece a otro inventario de paquetes.');id=parts[2];}else if(raw.includes(':'))throw Error('Esta etiqueta no es un QR de paquete de esta demo.');return unit(db,id.toUpperCase());}
function stats(db){return {packages:db.packages.length,boards:db.packages.reduce((n,p)=>n+p.quantity,0),pending:db.packages.filter(p=>p.status==='muelle').length,stored:db.packages.filter(p=>p.status==='almacen').length};}
function validate(input){
 if(!input||input.model!=='packages'||input.version!==1||typeof input.workspace!=='string'||!/^[a-z0-9]{4,16}$/.test(input.workspace)||!Array.isArray(input.packages)||input.packages.length>10000||!Array.isArray(input.events)||input.events.length>30000)throw Error('Esta copia no corresponde al inventario de paquetes. Los datos actuales se conservan.');
 const result=fresh();result.workspace=input.workspace;result.next=integer(input.next,'Secuencia',1,1000000);const ids=new Set();let highest=0;
 result.packages=input.packages.map(p=>{
  if(typeof p.id!=='string'||!/^PK-\d{5,6}$/.test(p.id)||ids.has(p.id)||!['muelle','almacen'].includes(p.status)||typeof p.labelConfirmed!=='boolean'||!Number.isFinite(Date.parse(p.receivedAt)))throw Error('La copia contiene un paquete no válido.');
  ids.add(p.id);highest=Math.max(highest,Number(p.id.slice(3)));
  if(p.status==='almacen'&&(!p.labelConfirmed||typeof p.location!=='string'||p.location.trim().toLocaleUpperCase('es')==='MUELLE'))throw Error('La ubicación de un paquete no es válida.');
  if(p.status==='muelle'&&p.location!==null)throw Error('El paquete pendiente tiene una ubicación incoherente.');
  return {id:p.id,color:text(p.color,'el color'),length:integer(p.length,'Largo'),width:integer(p.width,'Ancho'),thickness:integer(p.thickness,'Grosor',1,100),quantity:integer(p.quantity,'Tableros',1,1000),lot:text(p.lot,'el albarán',40),location:p.location===null?null:text(p.location,'la ubicación',30).toLocaleUpperCase('es'),status:p.status,labelConfirmed:p.labelConfirmed,receivedAt:new Date(p.receivedAt).toISOString(),sample:!!p.sample};
 });
 if(result.next<=highest)throw Error('La secuencia de paquetes no es válida.');
 result.events=input.events.map(e=>{if(!['recepcion','etiqueta','ubicacion'].includes(e.type)||!ids.has(e.packageId)||!Number.isFinite(Date.parse(e.date)))throw Error('El historial no es válido.');return {type:e.type,packageId:e.packageId,date:new Date(e.date).toISOString(),message:text(e.message,'el historial',250)};});return result;
}
function seed(){let db=fresh();for(const [color,thickness,location] of [['Jazmín',19,'A-01'],['Nómada',19,'A-02'],['Cielo',10,'B-01'],['Humo',35,'B-02']]){db=receive(db,{color,length:2800,width:2070,thickness,quantity:27,lot:'MUESTRA-'+location,sample:true});const id=db.packages.at(-1).id;db=confirmLabel(db,id);db=store(db,id,location);}return db;}
const api={key,legacyKey,colors,thicknesses,fresh,receive,confirmLabel,store,payload,lookup,stats,validate,seed};
if(typeof module!=='undefined')module.exports=api;else root.Packages=api;
})(typeof window!=='undefined'?window:globalThis);
