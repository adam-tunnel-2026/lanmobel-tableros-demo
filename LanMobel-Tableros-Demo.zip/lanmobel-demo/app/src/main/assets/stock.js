/* Inventory demo; all dimensions are integer millimetres. */
(function(root){
'use strict';
const VERSION=1;
const key='lanmobel-stock-demo-v1';
const clone=x=>JSON.parse(JSON.stringify(x));
function number(v,name,min=1,max=20000){const n=Number(v);if(!Number.isInteger(n)||n<min||n>max)throw Error(name+': introduce un número entero entre '+min+' y '+max+'.');return n;}
function text(v,name,max=60){if(typeof v!=='string'||!v.trim()||v.trim().length>max)throw Error('Revisa '+name+'.');return v.trim();}
function newDB(){return {version:VERSION,workspace:Math.random().toString(36).slice(2,10),next:1,items:[],events:[]};}
function id(db){return 'TB-'+String(db.next++).padStart(5,'0');}
function event(db,type,message,ids){db.events.unshift({type,message,ids,date:new Date().toISOString()});}
function transaction(db,fn){const next=clone(db);fn(next);return next;}
function receive(db,input){return transaction(db,next=>{
 const color=text(input.color,'color'),length=number(input.length,'Largo'),width=number(input.width,'Ancho'),thickness=number(input.thickness,'Grosor',1,100),quantity=number(input.quantity,'Cantidad',1,100),location=text(input.location,'ubicación',30),lot=text(input.lot,'lote / albarán',40);
 const ids=[];
 for(let n=0;n<quantity;n++){const item={id:id(next),color,length,width,thickness,location,lot,kind:'board',status:'available',parent:null,example:!!input.example};next.items.push(item);ids.push(item.id);}
 event(next,'entrada',quantity+' tablero'+(quantity===1?'':'s')+' · '+color+' · '+location,ids);
 });}
function available(db,itemId){const item=db.items.find(i=>i.id===itemId);if(!item||item.status!=='available')throw Error('Este tablero o retal ya no está disponible.');return item;}
function plan(item,length,width,kerf=3){
 length=number(length,'Largo de la pieza',1,item.length);width=number(width,'Ancho de la pieza',1,item.width);kerf=number(kerf,'Ancho de sierra',0,20);
 if(length<item.length&&length+kerf>item.length)throw Error('No queda espacio para el ancho de la sierra en el largo.');
 if(width<item.width&&width+kerf>item.width)throw Error('No queda espacio para el ancho de la sierra en el ancho.');
 const remaining=[];
 // First divide along the length; then divide the resulting strip across its width.
 if(length<item.length&&item.length-length-kerf>0)remaining.push({length:item.length-length-kerf,width:item.width});
 if(width<item.width&&item.width-width-kerf>0)remaining.push({length,width:item.width-width-kerf});
 const used=length*width,rest=remaining.reduce((sum,r)=>sum+r.length*r.width,0),waste=item.length*item.width-used-rest;
 return {length,width,kerf,remaining,used,rest,waste};
}
function cut(db,itemId,input){return transaction(db,next=>{
 const source=available(next,itemId),p=plan(source,input.length,input.width,input.kerf),job=text(input.job||'Corte de demostración','orden',50);source.status='cut';
 const ids=[source.id];
 for(const r of p.remaining){const remnant={...source,id:id(next),...r,status:'available',kind:'remnant',parent:source.id};next.items.push(remnant);ids.push(remnant.id);}
 event(next,'corte',source.id+' · pieza '+p.length+' × '+p.width+' mm · '+job,ids);
 next.events[0].cut={source:source.id,length:p.length,width:p.width,kerf:p.kerf,remaining:p.remaining,waste:p.waste};
 });}
function move(db,itemId,location){return transaction(db,next=>{const item=available(next,itemId),from=item.location;item.location=text(location,'ubicación',30);event(next,'traslado',item.id+' · '+from+' → '+item.location,[item.id]);});}
function payload(db,item){return 'LMB-DEMO:'+db.workspace+':'+item.id;}
function lookup(db,value){const valueText=String(value).trim();let itemId=valueText;if(valueText.startsWith('LMB-DEMO:')){const parts=valueText.split(':');if(parts.length!==3||parts[1]!==db.workspace)throw Error('Este QR pertenece a otra demo o a otro inventario.');itemId=parts[2];}const item=db.items.find(i=>i.id.toUpperCase()===itemId.toUpperCase());if(!item)throw Error('QR o identificador no encontrado en este inventario.');return item;}
function stats(db){const items=db.items.filter(i=>i.status==='available');return {boards:items.filter(i=>i.kind==='board').length,remnants:items.filter(i=>i.kind==='remnant').length,area:items.reduce((n,i)=>n+i.length*i.width/1e6,0),locations:new Set(items.map(i=>i.location)).size};}
function seed(){let db=newDB();for(const row of [
 ['Jazmín',2850,2100,19,8,'A-01','DEMO-001',false],['Nómada',3660,2100,19,5,'A-02','DEMO-001',false],['Jazmín',2850,2100,35,3,'B-01','DEMO-002',false],['Petrol',2800,2070,19,6,'B-02','DEMO-002',false],['Roble natural',2800,2070,19,4,'C-01','EJEMPLO-003',true],['Blanco mate',2850,2100,16,7,'C-02','EJEMPLO-003',true],['Grafito',2800,2070,25,2,'D-01','EJEMPLO-004',true]
 ]){const [color,length,width,thickness,quantity,location,lot,example]=row;db=receive(db,{color,length,width,thickness,quantity,location,lot,example});}return db;}
function validate(value){
 if(!value||value.version!==VERSION||typeof value.workspace!=='string'||!/^[a-z0-9]{4,16}$/.test(value.workspace)||!Array.isArray(value.items)||value.items.length>10000||!Array.isArray(value.events)||value.events.length>20000)throw Error('Copia de seguridad no válida.');
 const db=newDB();db.workspace=value.workspace;db.next=number(value.next,'Secuencia',1,1000000);const seen=new Set();let largest=0;
 db.items=value.items.map(i=>{if(typeof i.id!=='string'||!/^TB-\d{5,6}$/.test(i.id)||seen.has(i.id))throw Error('Identificadores no válidos.');seen.add(i.id);largest=Math.max(largest,Number(i.id.slice(3)));if(!['available','cut'].includes(i.status)||!['board','remnant'].includes(i.kind))throw Error('Estado no válido.');return {id:i.id,color:text(i.color,'color'),length:number(i.length,'Largo'),width:number(i.width,'Ancho'),thickness:number(i.thickness,'Grosor',1,100),location:text(i.location,'ubicación',30),lot:text(i.lot,'lote',40),kind:i.kind,status:i.status,parent:i.parent===null?null:text(i.parent,'origen',10),example:!!i.example};});
 if(db.next<=largest||db.items.some(i=>i.parent&&!seen.has(i.parent)))throw Error('Referencias no válidas.');
 db.events=value.events.map(e=>{if(!['entrada','corte','traslado'].includes(e.type)||!Array.isArray(e.ids)||e.ids.some(id=>!seen.has(id))||!Number.isFinite(Date.parse(e.date)))throw Error('Historial no válido.');return {type:e.type,message:text(e.message,'historial',250),ids:e.ids.map(String),date:new Date(e.date).toISOString()};});return db;
}
const api={key,newDB,receive,plan,cut,move,payload,lookup,stats,seed,validate};
if(typeof module!=='undefined')module.exports=api;else root.Stock=api;
})(typeof window!=='undefined'?window:globalThis);
