package es.lanmobel.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private String pendingBackup;
    private static final int OPEN_FILE=201, SAVE_BACKUP=202;
    private static final String ASSET="file:///android_asset/index.html";
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        web=new WebView(this);
        setContentView(web);
        WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request) {return !ASSET.equals(request.getUrl().toString());}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params) {
                if(chooser!=null)chooser.onReceiveValue(null);
                chooser=callback;
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try{startActivityForResult(intent,OPEN_FILE);return true;}catch(Exception e){chooser=null;return false;}
            }
        });
        web.addJavascriptInterface(new DemoBridge(),"AndroidDemo");
        web.loadUrl(ASSET);
    }
    private void notifyJS(String message){web.evaluateJavascript("window.onNativeMessage&&window.onNativeMessage("+JSONObject.quote(message)+")",null);}
    private final class DemoBridge {
        @JavascriptInterface public void scan(){runOnUiThread(()->{
            try{new IntentIntegrator(MainActivity.this).setDesiredBarcodeFormats(IntentIntegrator.QR_CODE).setPrompt("Escanea la etiqueta del tablero o retal").setBeepEnabled(false).setOrientationLocked(false).initiateScan();}
            catch(Exception e){notifyJS("No se ha podido abrir la cámara. Puedes buscar el identificador manualmente.");}
        });}
        @JavascriptInterface public void printLabel(){runOnUiThread(()->{
            try{PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);manager.print("LanMobel-Etiqueta",web.createPrintDocumentAdapter("Etiqueta de tablero"),null);}
            catch(Exception e){notifyJS("No se ha podido abrir la impresión.");}
        });}
        @JavascriptInterface public void exportBackup(String json){runOnUiThread(()->{
            if(json==null||json.length()>8000000){notifyJS("La copia supera el tamaño permitido.");return;}
            try{new JSONObject(json);pendingBackup=json;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");intent.putExtra(Intent.EXTRA_TITLE,"LanMobel-Demo-Copia.json");startActivityForResult(intent,SAVE_BACKUP);}
            catch(Exception e){pendingBackup=null;notifyJS("No se ha podido preparar la copia.");}
        });}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        if(requestCode==OPEN_FILE){if(chooser!=null){chooser.onReceiveValue(resultCode==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);chooser=null;}return;}
        if(requestCode==SAVE_BACKUP){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingBackup!=null){
                try(OutputStream stream=getContentResolver().openOutputStream(data.getData(),"wt")){if(stream==null)throw new Exception();stream.write(pendingBackup.getBytes(StandardCharsets.UTF_8));notifyJS("Copia guardada.");}catch(Exception e){notifyJS("No se ha podido guardar la copia.");}
            }
            pendingBackup=null;return;
        }
        IntentResult result=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);
        if(result!=null){if(result.getContents()!=null)web.evaluateJavascript("window.onQrRead("+JSONObject.quote(result.getContents())+")",null);else notifyJS("Escaneo cancelado. Puedes buscar por identificador.");return;}
        super.onActivityResult(requestCode,resultCode,data);
    }
    @Override public void onBackPressed(){web.evaluateJavascript("(function(){const dialogs=Array.from(document.querySelectorAll('dialog[open]'));if(dialogs.length){dialogs[dialogs.length-1].close();return true;}if(document.getElementById('view-stock').hidden){showTab('stock');return true;}return false;})()",value->{if(!"true".equals(value))finish();});}
    @Override protected void onDestroy(){if(chooser!=null){chooser.onReceiveValue(null);chooser=null;}web.removeJavascriptInterface("AndroidDemo");web.destroy();super.onDestroy();}
}
