package es.lanmobel.demo;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.util.Log;
import android.content.Intent;
import android.os.Bundle;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private String pendingBackup;
    private static final int OPEN_FILE=201, SAVE_BACKUP=202, CAMERA_PERMISSION=203;
    private boolean scanning=false;
    private static final String ASSET="file:///android_asset/index.html";
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        web=new WebView(this);
        setContentView(web);
        WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request) {return !ASSET.equals(request.getUrl().toString());}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params) {
                if(chooser!=null)chooser.onReceiveValue(null);
                chooser=callback;
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try{startActivityForResult(intent,OPEN_FILE);return true;}catch(Exception e){chooser=null;return false;}
            }
        });
        web.addJavascriptInterface(new DemoBridge(),"AndroidDemo");
        web.loadUrl(ASSET);
    }
    private void notifyJS(String message){web.evaluateJavascript("window.onNativeMessage&&window.onNativeMessage("+JSONObject.quote(message)+")",null);}
    public final class DemoBridge {
        @JavascriptInterface public void scan(){runOnUiThread(()->requestScanner());}
        @JavascriptInterface public void printLabel(){runOnUiThread(()->{
            try{PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);manager.print("LanMobel-Etiqueta",web.createPrintDocumentAdapter("Etiqueta de tablero"),null);}
            catch(Exception e){notifyJS("No se ha podido abrir la impresión.");}
        });}
        @JavascriptInterface public void exportBackup(String json){runOnUiThread(()->{
            if(json==null||json.length()>8000000){notifyJS("La copia supera el tamaño permitido.");return;}
            try{new JSONObject(json);pendingBackup=json;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");intent.putExtra(Intent.EXTRA_TITLE,"LanMobel-Paquetes-Copia.json");startActivityForResult(intent,SAVE_BACKUP);}
            catch(Exception e){pendingBackup=null;notifyJS("No se ha podido preparar la copia.");}
        });}
    }
    private void cameraError(String message){
        scanning=false;
        web.evaluateJavascript("window.onCameraError&&window.onCameraError("+JSONObject.quote(message)+")",null);
    }
    private void requestScanner(){
        if(scanning)return;
        if(!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)){
            cameraError("Este dispositivo no tiene cámara. Escribe el identificador del paquete.");return;
        }
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION);return;
        }
        startScanner();
    }
    private void startScanner(){
        scanning=true;
        try{
            new IntentIntegrator(MainActivity.this)
                .setCaptureActivity(QrCaptureActivity.class)
                .setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
                .setPrompt("Apunta al QR del paquete")
                .setBeepEnabled(false)
                .setOrientationLocked(true)
                .initiateScan();
        }catch(Exception error){
            Log.e("LanMobelCamera","Could not start scanner",error);
            cameraError("No se ha podido abrir la cámara. Revisa el permiso de cámara en Ajustes o escribe el identificador.");
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode!=CAMERA_PERMISSION)return;
        if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED){startScanner();return;}
        cameraError("No has permitido el acceso a la cámara. Puedes activarlo en Ajustes o buscar por identificador.");
        if(!shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)){
            new AlertDialog.Builder(this).setTitle("Permiso de cámara")
                .setMessage("Para leer las etiquetas QR, permite el acceso a la cámara en los ajustes de la app.")
                .setPositiveButton("Abrir ajustes",(dialog,which)->{
                    try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}
                    catch(Exception error){notifyJS("Abre Ajustes del móvil → Aplicaciones → Lan Mobel → Permisos.");}
                })
                .setNegativeButton("Ahora no",(dialog,which)->dialog.dismiss()).show();
        }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        if(requestCode==OPEN_FILE){if(chooser!=null){chooser.onReceiveValue(resultCode==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);chooser=null;}return;}
        if(requestCode==SAVE_BACKUP){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingBackup!=null){
                try(OutputStream stream=getContentResolver().openOutputStream(data.getData(),"wt")){if(stream==null)throw new Exception();stream.write(pendingBackup.getBytes(StandardCharsets.UTF_8));notifyJS("Copia guardada.");}catch(Exception e){notifyJS("No se ha podido guardar la copia.");}
            }
            pendingBackup=null;return;
        }
        IntentResult result=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);
        if(result!=null){scanning=false;if(result.getContents()!=null)web.evaluateJavascript("window.onQrRead("+JSONObject.quote(result.getContents())+")",null);else notifyJS("Escaneo cancelado. Puedes buscar por identificador.");return;}
        super.onActivityResult(requestCode,resultCode,data);
    }
    @Override public void onBackPressed(){web.evaluateJavascript("(function(){const dialogs=Array.from(document.querySelectorAll('dialog[open]'));if(dialogs.length){dialogs[dialogs.length-1].close();return true;}if(document.getElementById('view-receive').hidden){showTab('receive');return true;}return false;})()",value->{if(!"true".equals(value))finish();});}
    @Override protected void onDestroy(){if(chooser!=null){chooser.onReceiveValue(null);chooser=null;}web.removeJavascriptInterface("AndroidDemo");web.destroy();super.onDestroy();}
}
