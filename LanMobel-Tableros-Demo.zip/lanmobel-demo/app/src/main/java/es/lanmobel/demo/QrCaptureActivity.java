package es.lanmobel.demo;
import com.journeyapps.barcodescanner.CaptureActivity;
/** Portrait scanner owned by this app, with the library handling the camera lifecycle. */
public class QrCaptureActivity extends CaptureActivity { }
