const assert=require('node:assert/strict'),S=require('../app/src/main/assets/stock.js');
let db=S.seed();assert.equal(S.stats(db).boards,35);assert.equal(S.stats(db).remnants,0);
assert.equal(db.items.filter(i=>i.color==='Jazmín'&&i.thickness===35).length,3);
const source=db.items[0],qr=S.payload(db,source);assert.equal(S.lookup(db,qr).id,source.id);
assert.throws(()=>S.lookup(db,'LMB-DEMO:other:'+source.id));assert.throws(()=>S.lookup(db,'TB-99999'));
const before=JSON.stringify(db);assert.throws(()=>S.cut(db,source.id,{length:9999,width:500,kerf:3}));assert.equal(JSON.stringify(db),before,'failure is atomic');
const p=S.plan(source,500,300,3);assert.deepEqual(p.remaining,[{length:2347,width:2100},{length:500,width:1797}]);assert.equal(p.used+p.rest+p.waste,source.length*source.width);assert.equal(p.waste,7800);
let next=S.cut(db,source.id,{length:500,width:300,kerf:3,job:'OP-12'});assert.equal(S.stats(next).boards,34);assert.equal(S.stats(next).remnants,2);assert.equal(S.lookup(next,qr).status,'cut');assert.equal(db.items[0].status,'available','transaction does not mutate its input');
assert.throws(()=>S.cut(next,source.id,{length:500,width:300,kerf:3}),'double cut blocked');
const r=next.items.at(-1);assert.equal(r.parent,source.id);assert.equal(r.thickness,19);assert.equal(r.color,'Jazmín');
next=S.move(next,r.id,'RET-01');assert.equal(S.lookup(next,r.id).location,'RET-01');assert.equal(S.lookup(next,qr).location,'A-01');
const exact=S.plan(source,2850,2100,3);assert.equal(exact.remaining.length,0);assert.equal(exact.waste,0);
assert.throws(()=>S.plan(source,2849,2100,3));assert.equal(S.plan(source,2847,2100,3).remaining.length,0);
assert.throws(()=>S.receive(next,{color:'X',length:1,width:1,thickness:19,quantity:0,location:'A',lot:'X'}));
const backup=S.validate(JSON.parse(JSON.stringify(next)));assert.equal(S.stats(backup).remnants,2);assert.equal(backup.workspace,next.workspace);assert.equal(S.lookup(backup,qr).status,'cut');
const bad=JSON.parse(JSON.stringify(next));bad.items[1].id=bad.items[0].id;assert.throws(()=>S.validate(bad));
let check=S.newDB();check=S.receive(check,{color:'Prueba',length:1000,width:1000,thickness:19,quantity:1,location:'A',lot:'L'});
for(let k=0;k<=10;k++){for(const dims of [[100,100],[1000,100],[100,1000],[1000,1000]]){const x=S.plan(check.items[0],...dims,k);assert.equal(x.used+x.rest+x.waste,1e6);assert.ok(x.waste>=0);}}
console.log('PASS: stock by thickness, independent QR identity, atomic transactions, guillotine geometry, kerf conservation, double-cut prevention, remnant genealogy, moves and backup validation.');
