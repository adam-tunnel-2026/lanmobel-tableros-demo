const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const root=__dirname+'/../app/src/main/assets/',html=fs.readFileSync(root+'index.html','utf8');
class Element{constructor(){this.value='';this.textContent='';this.innerHTML='';this.hidden=false;this.open=false;this.dataset={};this.attributes={};this.style={setProperty(){}};}setAttribute(k,v){this.attributes[k]=v;}addEventListener(type,fn){(this.listeners??={})[type]=fn;}showModal(){this.open=true;}close(){const was=this.open;this.open=false;if(was)this.listeners?.close?.();}click(){}scrollIntoView(){} }
const elements=Object.fromEntries([...html.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],new Element()]));
for(const [id,value] of [['quantity','27'],['board-length','2800'],['board-width','2070'],['thickness-value','19']])elements[id].value=value;
const legacy='{"version":1,"items":[{"id":"TB-00001"}]}',map=new Map([['lanmobel-stock-demo-v1',legacy]]),main=new Element(),nav=new Element();let failSave=false,scanCalls=0,printCalls=0;
const c=vm.createContext({console,Math,Date,JSON,String,Number,Set,Map,Array,Error,Object,Promise,Blob,URL,
 document:{getElementById:id=>elements[id],querySelectorAll:()=>[],querySelector:s=>s==='main'?main:nav,createElement:()=>new Element(),body:new Element()},
 localStorage:{getItem:k=>map.get(k)||null,setItem:(k,v)=>{if(failSave)throw Error('Sin espacio para guardar');map.set(k,v);}},setTimeout(){return 1},clearTimeout(){},scrollTo(){}});c.window=c;
for(const file of ['packages.js','qr.js','app.js'])vm.runInContext(fs.readFileSync(root+file,'utf8'),c);
const run=s=>vm.runInContext(s,c);
(async()=>{
 assert.equal(elements['view-receive'].hidden,false);assert.equal(elements['total-packages'].textContent,4);assert.equal(elements['total-boards'].textContent,108);assert.equal(elements['pending-packages'].textContent,0);assert.equal(map.get('lanmobel-stock-demo-v1'),legacy,'old inventory not changed');assert.equal(elements['legacy-export'].hidden,false);
 for(const color of ['Jazmín','Nómada','Cielo','Humo','Kenya','Haya','Juice','Mustard','Trufa','Nude'])assert.ok(elements['color-grid'].innerHTML.includes(color));
 for(const t of [19,35,10,4])assert.ok(elements['thickness-options'].innerHTML.includes(t+' mm'));
 run("$('receive-form').onsubmit({preventDefault(){}})");assert.equal(elements['total-packages'].textContent,5);assert.equal(elements['total-boards'].textContent,135);assert.equal(elements['pending-packages'].textContent,1);assert.equal(run('db.packages.length'),5,'one QR record for all 27 boards');assert.equal(run('currentId'),'PK-00005');
 assert.equal((elements['paper-label'].innerHTML.match(/<svg/g)||[]).length,1);assert.match(elements['paper-label'].innerHTML,/27 <em>tableros/);assert.match(elements['paper-label'].innerHTML,/2800 × 2070 × 19 mm/);assert.equal(elements['store-form'].hidden,true);
 run("$('receive-form').onsubmit({preventDefault(){}})");assert.equal(run('db.packages.length'),5,'repeated submit while receipt open cannot duplicate a package');
 // Starting print does not falsely confirm that a physical label has been placed.
 c.AndroidDemo={scan(){scanCalls++;},printLabel(){printCalls++;},exportBackup(){}};
 run("$('print-label').onclick()");assert.equal(printCalls,1);assert.equal(run("Packages.lookup(db,currentId).labelConfirmed"),false);assert.equal(c.document.body.dataset.printMode,'package');
 elements['store-location'].value='A-07';run("$('store-form').onsubmit({preventDefault(){}})");assert.match(elements['store-error'].textContent,/etiqueta/);
 run("$('confirm-label').onclick()");assert.equal(elements['store-form'].hidden,false);assert.equal(run('db.packages.length'),5);elements['store-location'].value='A-07';run("$('store-form').onsubmit({preventDefault(){}})");assert.equal(elements['pending-packages'].textContent,0);assert.equal(elements['total-boards'].textContent,135);assert.equal(run("db.packages[4].location"),'A-07');assert.equal(elements['view-stock'].hidden,false);
 run("onQrRead(Packages.payload(db,db.packages[4]))");assert.equal(elements['current-location-value'].textContent,'A-07');assert.match(elements['package-subtitle'].textContent,/1 paquete · 27 tableros/);run("$('package-dialog').close();chooseColor('Mustard');chooseThickness(35)");elements.quantity.value='26';run("$('receive-form').onsubmit({preventDefault(){}})");assert.equal(run('db.packages.length'),6);assert.equal(elements['total-boards'].textContent,161);assert.match(elements['paper-label'].innerHTML,/Mustard/);assert.match(elements['paper-label'].innerHTML,/26 <em>tableros/);assert.match(elements['paper-label'].innerHTML,/35 mm/);
 run("$('package-dialog').close()");failSave=true;run("$('receive-form').onsubmit({preventDefault(){}})");assert.equal(run('db.packages.length'),6);assert.match(elements['receive-error'].textContent,/Sin espacio/);failSave=false;
 run("$('camera').onclick()");assert.equal(scanCalls,1);run("onCameraError('Permiso denegado')");assert.equal(elements['scan-error'].textContent,'Permiso denegado');delete c.AndroidDemo;run("$('camera').onclick()");assert.match(elements['scan-error'].textContent,/app instalada/);
 // A legacy JSON cannot overwrite the new package inventory.
 const fileElement={files:[{size:100,text:async()=>legacy}],value:'old.json'};c.testImport={target:fileElement};await run("$('import').onchange(testImport)");assert.match(elements['backup-error'].textContent,/inventario de paquetes/);assert.equal(run('db.packages.length'),6);assert.equal(elements['restore-confirm'].open,false);assert.equal(map.get('lanmobel-stock-demo-v1'),legacy);
 const saved=JSON.parse(map.get('lanmobel-packages-demo-v1'));assert.equal(saved.packages.length,6);assert.equal(saved.packages[4].quantity,27);assert.equal(saved.packages[4].location,'A-07');
 // A color at the end of the strip must still reach the package and its printed label.
 const tile={dataset:{color:'Nude'}};c.lastTile=tile;run("$('color-grid').onclick({target:{closest(){return lastTile;}}})");assert.equal(elements['selected-color'].textContent,'Nude');elements.quantity.value='27';run("$('receive-form').onsubmit({preventDefault(){}})");assert.equal(run('db.packages.at(-1).color'),'Nude');assert.match(elements['paper-label'].innerHTML,/Nude/);assert.equal(run('db.packages.length'),7);

 console.log('PASS: package UI, requested catalog, one QR/27 boards, duplicate-submit guard, honest print confirmation, label and storage flow, counted quantity 26, camera bridge/error handling, persistence and untouched legacy inventory.');
})().catch(e=>{console.error(e);process.exitCode=1;});
