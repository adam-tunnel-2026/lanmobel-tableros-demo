const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const root=__dirname+'/../app/src/main/assets/',html=fs.readFileSync(root+'index.html','utf8');
class Element{constructor(){this.value='';this.textContent='';this.innerHTML='';this.hidden=false;this.open=false;this.dataset={};this.classList={toggle(){}};}showModal(){this.open=true}close(){this.open=false}click(){} }
const elements=Object.fromEntries([...html.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],new Element()]));
for(const [id,value] of [['cut-length','500'],['cut-width','300'],['cut-kerf','3'],['cut-job','OP-1']])elements[id].value=value;
const map=new Map(),main=new Element(),nav=new Element();let failSave=false;
const c=vm.createContext({console,Math,Date,JSON,String,Number,Set,Map,Array,Error,Object,Promise,
 document:{getElementById:id=>elements[id],querySelectorAll:()=>[],querySelector:s=>s==='main'?main:nav,createElement:()=>new Element()},
 localStorage:{getItem:k=>map.get(k)||null,setItem:(k,v)=>{if(failSave)throw Error('Sin espacio para guardar');map.set(k,v);}},setTimeout(){return 1},clearTimeout(){},scrollTo(){},FormData:class{constructor(form){return Object.entries(form.data)[Symbol.iterator]()}},Blob,URL});c.window=c;
for(const file of ['stock.js','qr.js','app.js'])vm.runInContext(fs.readFileSync(root+file,'utf8'),c);
const run=s=>vm.runInContext(s,c);
assert.equal(elements['count-boards'].textContent,35);assert.match(elements.inventory.innerHTML,/Jazmín/);
run("openItem('TB-00001')");assert.equal(elements.detail.open,true);assert.match(elements['label-card'].innerHTML,/<svg/);assert.match(elements['label-card'].innerHTML,/TB-00001/);
run('preview()');assert.match(elements['cut-preview'].innerHTML,/2347 × 2100/);
run("$('cut-form').onsubmit({preventDefault(){}})");assert.equal(elements['cut-form'].hidden,true);assert.equal(elements['count-boards'].textContent,34);assert.equal(elements['count-remnants'].textContent,2);assert.match(elements.children.innerHTML,/TB-00036/);
run("openItem('TB-00036')");elements['move-location'].value='RET-02';run("$('move-form').onsubmit({preventDefault(){}})");assert.match(elements['label-card'].innerHTML,/RET-02/);
run("$('receive-form').data={color:'<img src=x>',length:'2850',width:'2100',thickness:'19',quantity:'2',location:'A-04',lot:'TEST'};$('receive-form').onsubmit({target:$('receive-form'),preventDefault(){}})");assert.equal(elements['count-boards'].textContent,36);assert.match(elements.inventory.innerHTML,/&lt;img src=x&gt;/);assert.doesNotMatch(elements.inventory.innerHTML,/<img src=x>/);
run("openItem('TB-00002')");failSave=true;run("$('cut-form').onsubmit({preventDefault(){}})");assert.equal(run("Stock.lookup(db,'TB-00002').status"),'available');assert.match(elements['cut-error'].textContent,/Sin espacio/);
failSave=false;run("onQrRead(Stock.payload(db,db.items[0]))");assert.equal(elements['cut-form'].hidden,true,'old QR retains consumed status');assert.equal(elements['view-scan'].hidden,false);
console.log('PASS: initial UI, QR generation, cut preview and submission, movement, receiving, HTML escaping, storage failure atomicity and old-QR lookup.');
