# Lan Mobel · Control de tableros — demo 0.1.0

Demo funcional de inventario local. Propuesta, no app oficial de la empresa.

## Probar ahora

Abre `LanMobel-Demo.html` en un navegador que permita almacenamiento local. Es una demo sin instalación: inventario, entradas, QR, cambios de ubicación y cortes funcionan sin conexión. El escáner de cámara necesita la APK; en el navegador puedes buscar un identificador o pulsar «Probar con TB-00001».

La demo inicia 35 tableros. Solo los nombres y medidas indicados por el usuario se han tomado como referencias; todas las cantidades, ubicaciones, lotes y movimientos de muestra son ficticios. Roble natural, Blanco mate y Grafito son ejemplos añadidos. Los colores visibles son aproximaciones gráficas.

## Recorrido para presentar

1. Abre Inventario: Jazmín 2850 × 2100 × 19 mm. Hay 8 unidades de muestra en A-01.
2. Toca TB-00001. Verás un QR único, albarán, medidas y ubicación. Imprime la etiqueta con el sistema de impresión de Android (o guarda en PDF).
3. Pulsa «Calcular retales» con pieza 500 × 300 mm y sierra 3 mm.
4. Quedarán dos retales: 2347 × 2100 × 19 y 500 × 1797 × 19 mm.
5. Confirma el corte. El tablero original deja de estar disponible. Quedan 34 tableros completos y 2 retales en total.
6. Abre un retal: tiene nuevo QR y referencia al tablero de origen. Muévelo a RET-01.
7. Escanea el QR original: conserva su historia y muestra que ya está cortado.
8. Registra una entrada desde un camión. Cada unidad recibe su QR aunque todas compartan albarán y ubicación.
9. Consulta Movimientos. Exporta una copia JSON desde el menú superior.

## Generar la APK mediante GitHub Actions

Este paquete contiene código fuente y demo HTML; NO contiene una APK ya compilada. Este entorno no dispone del SDK Android ni puede descargarlo del repositorio de Google. Las pruebas de lógica y de integración con una simulación de la interfaz han pasado; falta compilar y probar en Android real.

Utiliza un repositorio NUEVO para esta demo, separado de Encajoy, Órbita Flash y Adam Tunnel. Puede ser privado. No hay que tocar ningún repositorio existente.

1. Crea el repositorio en https://github.com/new con nombre `lanmobel-tableros-demo` y añade un README.
2. Sube `LanMobel-Tableros-Demo.zip` SIN descomprimir a la raíz del repositorio.
3. Descomprime una copia del ZIP en el móvil y localiza `lanmobel-demo/.github/workflows/lanmobel-demo.yml`.
4. En GitHub, entra en Add file → Create new file. Nombre: `.github/workflows/lanmobel-demo.yml`. Copia el texto del YML y guarda el commit. Alternativamente, desde la carpeta `.github/workflows` sube el archivo YML extraído.
5. Abre Actions → «Lan Mobel - Demo de tableros» → Run workflow. El workflow ejecuta las pruebas y compila Android.
6. Cuando termine en verde, abre la ejecución y descarga el artefacto `LanMobel-Tableros-Demo-APK`. El ZIP del artefacto contiene `LanMobel-Tableros-Demo.apk`.
7. Instala la APK. Concede acceso a la cámara únicamente cuando quieras leer QR. Puedes usar el identificador escrito si no das ese permiso.

Requisitos de compilación: Java 17, Gradle 8.9, Android SDK 35, AGP 8.7.3. Si se compila localmente: `gradle :app:assembleDebug`. APK de demostración con firma debug, no preparada para publicar ni para actualizaciones permanentes en producción. El archivo subido a Actions se conserva solo 3 días para reducir almacenamiento.

## Qué hace y qué no hace

- Una identidad por unidad física; el QR identifica esa unidad y este inventario local, no contiene un enlace web.
- El mismo QR sigue funcionando tras un traslado. Si la ubicación figura impresa, se debe reimprimir la etiqueta.
- Referencias diferenciadas por acabado, largo, ancho, grosor y tipo (tablero/retal). Búsqueda por ubicación y filtro de grosor.
- Un corte consume una unidad disponible, nunca dos veces, y registra hasta dos retales rectangulares no solapados.
- El modelo hace primero una división en el largo y luego otra en el ancho de la tira. Se descuenta la sierra en cada división aplicable. No es un optimizador de despiece ni admite planos arbitrarios de una máquina.
- La pieza cortada se considera salida a producción; no se añade como producto terminado en almacén.
- No lee automáticamente los cortes de Selco, Schilling ni otras máquinas. Hay que registrar cada operación manualmente y poner etiquetas a los retales.
- Los cambios se guardan solo en el dispositivo. Dos móviles no comparten inventario ni pueden leer los QR del inventario del otro sin restaurar la misma copia. Restaurar una copia sustituye los datos locales; no fusiona inventarios.
- La cámara y la impresión requieren probarse en un dispositivo real. La impresión depende del servicio de impresión instalado.
- Exportar/importar JSON permite conservar una copia. Desinstalar o borrar los datos elimina el inventario local. La demo HTML y la APK tienen almacenamientos separados.
- No incluye cuentas, roles, auditoría contra manipulaciones, red de empresa, servidores, lectores industriales ni datos reales de Lan Mobel.

## Siguiente fase para uso real

Validar primero con el encargado las ubicaciones, acabados y reglas de retales. Para trabajar entre varias personas: base de datos compartida, usuarios y permisos, transacciones del servidor para evitar descontar dos veces, copias automáticas y registro del operario. La integración de máquinas dependerá de sus formatos de exportación y acceso autorizado.

## Pruebas incluidas

`node tests/stock.test.cjs` comprueba grosores, identidad QR, consumo único, geometría y pérdidas por sierra, retales, traslados, atomicidad y copias.

`node tests/ui.test.cjs` comprueba el recorrido de entradas y cortes, QR generado, escape de nombres, errores de guardado y consulta del QR original con una simulación de DOM. No sustituye una prueba visual en Android.

## Dependencias

QRCode for JavaScript (Kazuhiko Arase, MIT), distribuido con avisos en `THIRD-PARTY.txt` y comentarios de origen. Biblioteca de cámara ZXing Android Embedded 4.3.0 y sus dependencias para la compilación Android. No se incluyen claves ni credenciales.
