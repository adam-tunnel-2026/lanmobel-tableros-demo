# Lan Mobel · Demo de paquetes 0.4.0

## El modelo correcto de trabajo

Un paquete físico tiene un único identificador y un único QR. El número de tableros es una propiedad de ese paquete, no una lista de etiquetas individuales.

Ejemplo aportado por el usuario: un paquete de Jazmín de 2800 × 2070 × 19 mm contiene 27 tableros. Al registrarlo se crea UN paquete y UNA etiqueta QR, con el texto «27 tableros». La cantidad puede ser 26, 28 u otra si el recuento real difiere.

Colores incluidos: Jazmín, Nómada, Cielo, Humo, Kenya, Haya, Juice, Mustard, Trufa y Nude. Medidas iniciales 2800 × 2070 mm y selector de grosores 19, 35, 10 y 4 mm. Las medidas pueden editarse antes de registrar. Los colores visuales son aproximaciones, no muestras del fabricante.

## Recorrido de demostración

1. La app abre en Descarga. Selecciona color y grosor, revisa medidas y cuenta los tableros. La cantidad inicial es 27, editable.
2. Pulsa «Crear paquete y etiqueta QR». Se crea una ficha PK-xxxxx para todo el paquete. Dos pulsaciones mientras la ficha permanece abierta no duplican la descarga.
3. La etiqueta muestra color, medidas, cantidad, albarán e identificador con un solo QR. Abre la impresión del móvil y pega la etiqueta en el tablero superior.
4. Pulsa «Etiqueta colocada · Asignar ubicación». Este botón es una confirmación manual: abrir el diálogo de impresión no se considera prueba de haber impreso o pegado una etiqueta.
5. Indica ubicación, por ejemplo A-01, y confirma. El paquete completo, con sus 27 tableros, pasa del muelle al almacén.
6. En Almacén se ven paquetes y cantidad total de tableros. Los pendientes de ubicar se distinguen de los almacenados. Puedes buscar por color, grosor, identificador, ubicación o albarán.
7. Leer QR abre la ficha del paquete y su ubicación actual. El QR no cambia al trasladar el paquete. La ubicación se consulta en la app y no queda impresa como un dato que podría quedar obsoleto.

En esta fase no hay cortes ni gestión de retales. Tampoco se divide un paquete entre varias ubicaciones: un paquete físico tiene una ubicación.

## Datos de demostración y versiones anteriores

Al crear el inventario se incluyen cuatro paquetes claramente marcados «Muestra»: Jazmín 19 mm, Nómada 19 mm, Cielo 10 mm y Humo 35 mm; cada uno contiene 27 tableros. Son cuatro paquetes y 108 tableros ficticios, almacenados en ubicaciones de ejemplo. No representan el stock real de la empresa.

Se usa un inventario de paquetes separado del antiguo inventario de unidades de tablero. Los datos de la demo anterior se conservan en su clave de almacenamiento y no se agrupan automáticamente: no sería correcto asumir qué tableros antiguos forman un paquete físico. En el menú aparece la opción de exportar la copia anterior si existe.

La copia nueva tiene modelo `packages`. La restauración rechaza el formato antiguo para evitar que sustituya por error los paquetes actuales. Exportar/importar es local; no fusiona dos móviles ni sincroniza inventarios.

## APK y GitHub

Versión Android 0.4.0, versionCode 4. Conserva el identificador de app es.lanmobel.demo. El ZIP mantiene la raíz `lanmobel-demo/` para los workflows ya preparados.

Sube `LanMobel-Tableros-Demo.zip` SIN descomprimir a la raíz de `adam-tunnel-2026/lanmobel-tableros-demo`, sustituyendo el archivo con ese nombre exacto. El workflow «Lan Mobel - APK desde ZIP» puede leerlo. El workflow de detección automática también elige el proyecto con el versionCode más alto.

Si se ha movido el workflow a otro nombre y no arranca automáticamente, abre ese workflow en Actions y usa Run workflow sobre main. El resultado descargable es el artefacto `LanMobel-Demo-Android`, con `LanMobel-Tableros-Demo.apk` dentro.

Requisitos: Java 17, Gradle 8.9, Android SDK 35. Compilación local: `gradle :app:assembleDebug`. Dependencia de cámara: ZXing Android Embedded 4.3.0.

La compilación Android NO se ha ejecutado en este entorno. Las pruebas de modelo y flujo de interfaz han pasado en Node; no son una prueba visual en Android. La cámara, la impresión con la impresora elegida y el aspecto final en el móvil requieren comprobación en dispositivo. El navegador de pruebas no pudo arrancar por restricciones del entorno.

Las APK son de prueba. Si Android rechaza instalar una actualización por firma diferente, guarda los datos antes de desinstalar. La firma debug reutilizada mediante caché de Actions depende de que la caché siga disponible; no es una firma permanente de producción.

## Cámara e impresión

La cámara usa una actividad QR nativa incluida en la APK. Se solicita permiso al usarla; si se deniega se muestra información y se permite la búsqueda manual. El lector muestra errores sin dejar la pantalla bloqueada. No sube imágenes.

La impresión utiliza el sistema de impresión Android. Se puede guardar una etiqueta como PDF o elegir una impresora compatible mediante el servicio instalado. No se garantiza compatibilidad con una impresora industrial concreta que no se haya probado. La etiqueta está preparada para un ancho aproximado de 95 mm, con QR de 30 mm; revisa la escala y legibilidad antes de pegar etiquetas reales.

## Alcance

Propuesta de demostración para presentar a Lan Mobel. No es una aplicación oficial, no contiene datos internos y no conecta con máquinas ni sistemas de la empresa. No incluye usuarios compartidos ni servidor. Todo se guarda en este dispositivo; desinstalar o borrar datos elimina el inventario local. Para un piloto real harán falta validar ubicaciones y etiquetas con el responsable y acordar acceso multiusuario y copias automáticas.

## Validación

- `node tests/stock.test.cjs`: un paquete y un QR para 27 tableros, cantidad real editable, colores y grosores, etiqueta antes de ubicación, QR estable, confirmaciones idempotentes y copias coherentes.
- `node tests/ui.test.cjs`: recorrido de descarga, QR único, impresión sin confirmación ficticia, ubicación, recuento de 26 tableros, protección frente a doble pulsación, errores de almacenamiento y cámara, y conservación de datos anteriores.
- Los XML se comprueban sintácticamente y el ZIP se verifica para integridad y extracción.

Avisos de dependencias en THIRD-PARTY.txt. QRCode JavaScript se distribuye con sus avisos. No se necesitan credenciales en el chat.
